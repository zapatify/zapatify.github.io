---
title: Home
layout: home
nav_order: 1
---

# Engineering Leadership & Innovation

Welcome! I'm **Rich Zapata**, an experienced engineering leader with a passion for building scalable fintech solutions and elegant software architectures. With over seven years leading engineering teams and a strong foundation in Ruby on Rails development, I focus on creating robust, production-ready applications that solve real-world problems.

## About Me

As Senior Director of Engineering at IOU Financial, I grew the engineering organization from 4 to 30+ employees across four countries, leading initiatives in:

- Full-stack web application development (Ruby on Rails, React)
- Financial technology and lending platforms
- Team building and mentorship across distributed teams
- Cloud infrastructure and DevOps (AWS)
- API design and microservices architecture

I'm currently exploring new opportunities in engineering leadership while building tools and sharing knowledge with the developer community.

## Featured Projects

Browse the navigation to explore my recent work, including:

- **JobZappy** - AI-powered resume optimization SaaS platform
- **ZappyNotes** - Comprehensive note-taking application with subscription tiers
- **TKTrakker** - Discord bot for gaming analytics and team tracking
- **Amortizy** - Ruby gem for loan amortization calculations
- **Fear, Faith, and the Forest** - Podcast guiding professionals through unemployment

Each project demonstrates different aspects of modern software development, from SaaS architecture and payment processing to open-source libraries and real-time systems. The podcast represents my commitment to helping others navigate career transitions with strategy and faith.

## Technical Expertise

**Languages & Frameworks:** Ruby on Rails, JavaScript, React, SQL, Python  
**Infrastructure:** AWS, Heroku, PostgreSQL, Redis, Docker  
**Specialties:** Fintech, API Design, Team Leadership, System Architecture

---

*Currently based in Atlanta, Georgia, and available for engineering leadership roles.*
